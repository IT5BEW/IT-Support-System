<?php
// Database.php
// แทนที่ Supabase.php ทั้งหมด
// รูปภาพทั้งหมดเก็บเป็น VARBINARY(MAX) ใน SQL Server
// เชื่อมต่อผ่าน ODBC (ไม่ต้องติดตั้ง extension เพิ่ม)

// ===================================================
// Private Helpers
// ===================================================

function init_env(string $path): void {
    if (!file_exists($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (str_contains($line, '=')) {
            [$name, $value] = explode('=', $line, 2);
            $_ENV[trim($name)] = trim($value);
        }
    }
}

function get_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    init_env(__DIR__ . '/.env');

    $host   = $_ENV['DB_HOST']         ?? 'localhost';
    $port   = $_ENV['DB_PORT']         ?? '1433';
    $dbname = $_ENV['DB_NAME']         ?? '';
    $user   = $_ENV['DB_USER']         ?? '';
    $pass   = $_ENV['DB_PASSWORD']     ?? '';
    $driver = $_ENV['DB_ODBC_DRIVER']  ?? 'ODBC Driver 17 for SQL Server';

    $pdo = new PDO(
        "odbc:Driver={$driver};Server=$host,$port;Database=$dbname;TrustServerCertificate=yes",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    return $pdo;
}

function get_mime_from_data(string $data): string {
    return (new finfo(FILEINFO_MIME_TYPE))->buffer($data);
}

function mime_to_ext(string $mime): string {
    return match($mime) {
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
        'image/gif'  => 'gif',
        default      => 'bin',
    };
}

// แปลง BLOB จาก SQL Server -> data URI สำหรับใช้ใน <img src="...">
// เช่น blob_to_data_uri($row['Signature'], $row['SignatureMime'])
function blob_to_data_uri(?string $blob, ?string $mime): ?string {
    if (empty($blob) || empty($mime)) return null;
    return "data:$mime;base64," . base64_encode($blob);
}

// ===================================================
// Public Functions (แทน supabase_query)
// ===================================================

// SELECT - คืน array of rows
// ตัวอย่าง: db_query('SELECT * FROM "Users" WHERE "User_ID" = :id', [':id' => 'U001'])
function db_query(string $sql, array $params = []): array {
    // ODBC: แปลง :param -> CAST(:param AS NVARCHAR(500)) เพื่อแก้ type mismatch
    $sql = preg_replace('/:(\w+)/', 'CAST(:$1 AS NVARCHAR(500))', $sql);
    $stmt = get_db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// INSERT - คืน true/false
function db_insert(string $table, array $data): bool {
    $cols         = array_keys($data);
    $placeholders = array_map(fn($c) => ":$c", $cols);
    $colList      = implode(', ', array_map(fn($c) => "[$c]", $cols));
    $valList      = implode(', ', $placeholders);

    $params = [];
    foreach ($data as $col => $val) {
        $params[":$col"] = $val;
    }

    $castList = implode(', ', array_map(fn($c) => "CAST(:$c AS NVARCHAR(MAX))", $cols));
    $stmt = get_db()->prepare("INSERT INTO [$table] ($colList) VALUES ($castList)");
    return $stmt->execute($params);
}

// UPDATE - คืน true/false
// $where คือ array ของเงื่อนไข เช่น ['User_ID' => 'U001']
function db_update(string $table, array $data, array $where): bool {
    $setParts   = array_map(fn($c) => "[$c] = CAST(:set_$c AS NVARCHAR(MAX))", array_keys($data));
    $whereParts = array_map(fn($c) => "[$c] = CAST(:where_$c AS NVARCHAR(MAX))", array_keys($where));

    $sql = "UPDATE [$table] SET " . implode(', ', $setParts)
         . " WHERE "              . implode(' AND ', $whereParts);

    $params = [];
    foreach ($data  as $col => $val) $params[":set_$col"]   = $val;
    foreach ($where as $col => $val) $params[":where_$col"] = $val;

    $stmt = get_db()->prepare($sql);
    return $stmt->execute($params);
}

// ===================================================
// File Functions (เก็บ BLOB ใน SQL Server)
// ===================================================

// อัปโหลดลายเซ็นจากไฟล์ที่ user upload มา
// คืน ['success' => true, 'mime' => '...']
// หรือ ['success' => false, 'error_msg' => '...']
function uploadSignature(string $user_id, array $file): array {
    $data = file_get_contents($file['tmp_name']);
    if ($data === false) {
        return ['success' => false, 'error_msg' => 'ไม่สามารถอ่านไฟล์ได้'];
    }

    $mime = get_mime_from_data($data);

    $ok = db_update('Users',
        ['Signature' => $data, 'SignatureMime' => $mime],
        ['User_ID'   => $user_id]
    );

    return $ok
        ? ['success' => true, 'mime' => $mime]
        : ['success' => false, 'error_msg' => 'บันทึกลงฐานข้อมูลไม่สำเร็จ'];
}

// เปลี่ยน User ID — signature อยู่ใน DB แล้ว ไม่ต้องย้ายไฟล์
// คืน ['success' => true] เสมอ (ให้ไว้เพื่อ backward compatible กับโค้ดที่เรียกใช้)
function updateSignatureWhenChangeUserID(string $old_user_id, string $new_user_id): array {
    // Signature ผูกกับ Users row ไม่ใช่ชื่อไฟล์
    // เมื่อ User_ID เปลี่ยน row ก็ย้ายตามอัตโนมัติ ไม่ต้องทำอะไรเพิ่ม
    return ['success' => true];
}

// ลบลายเซ็น
function deleteSignatureByUserId(string $user_id): array {
    $ok = db_update('Users',
        ['Signature' => null, 'SignatureMime' => null],
        ['User_ID'   => $user_id]
    );

    return $ok
        ? ['success' => true]
        : ['success' => false, 'error_msg' => 'ลบลายเซ็นออกจากฐานข้อมูลไม่สำเร็จ'];
}

// อัปโหลดรูปภาพประกอบฟอร์มจากไฟล์ที่ user upload มา
// column ที่จะ update ต้องส่งมาเป็น $image_col และ $mime_col
// เช่น uploadImageToForm($form_id, $file, 'DetailedImage', 'DetailedImageMime')
function uploadImageToForm(string $form_id, array $file, string $image_col, string $mime_col = ''): array {
    if (empty($mime_col)) $mime_col = $image_col . 'Mime';

    $data = file_get_contents($file['tmp_name']);
    if ($data === false) {
        return ['success' => false, 'error_msg' => 'ไม่สามารถอ่านไฟล์ได้'];
    }

    $mime = get_mime_from_data($data);

    $ok = db_update('RequestForm',
        [$image_col => $data, $mime_col => $mime],
        ['Form_ID'  => $form_id]
    );

    return $ok
        ? ['success' => true, 'mime' => $mime]
        : ['success' => false, 'error_msg' => 'บันทึกลงฐานข้อมูลไม่สำเร็จ'];
}

// copy ลายเซ็นจาก Users ไปเก็บใน RequestForm ณ เวลาที่ส่งฟอร์ม
// (snapshot ลายเซ็น เผื่อ user เปลี่ยนลายเซ็นทีหลัง ฟอร์มเก่ายังถูกต้อง)
function getImageFromUrlAndUploadToForm(string $form_id, string $user_id, string $col_prefix = 'Signature'): array {
    $image_col = $col_prefix;
    $mime_col  = $col_prefix . 'Mime';

    // ดึง BLOB ลายเซ็นของ user จาก DB โดยตรง
    $rows = db_query(
        'SELECT [Signature], [SignatureMime] FROM [Users] WHERE [User_ID] = :id',
        [':id' => $user_id]
    );

    if (empty($rows) || empty($rows[0]['Signature'])) {
        return ['success' => false, 'error_msg' => 'ไม่พบลายเซ็นของผู้ใช้'];
    }

    $blob = $rows[0]['Signature'];
    $mime = $rows[0]['SignatureMime'];

    $ok = db_update('RequestForm',
        [$image_col => $blob, $mime_col => $mime],
        ['Form_ID'  => $form_id]
    );

    return $ok
        ? ['success' => true, 'mime' => $mime]
        : ['success' => false, 'error_msg' => 'บันทึกลงฐานข้อมูลไม่สำเร็จ'];
}

// ลบรูปภาพประกอบฟอร์ม
function deleteFilesByPrefix(string $form_id, string $image_col, string $mime_col = ''): void {
    if (empty($mime_col)) $mime_col = $image_col . 'Mime';

    db_update('RequestForm',
        [$image_col => null, $mime_col => null],
        ['Form_ID'  => $form_id]
    );
}